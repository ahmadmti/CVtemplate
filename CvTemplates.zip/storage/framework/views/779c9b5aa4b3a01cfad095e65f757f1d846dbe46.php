<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <style>
        /* @font-face {
            font-family: Calibri Regular;
            src: url(<?php echo e(url('fonts/Calibri Regular.ttf')); ?>);
        } */
        *{
            font-size: 13px;
            /* font-family: Calibri Regular; */
        }
        div {
            /* border: 1px solid #ff0000; */
            padding: 5px;
        }
        table, th, tr{
            width: 100%;
            /* border: 2px solid rgb(4, 0, 255); */
        }
        td{
            /* border: 2px solid rgb(4, 0, 255); */
            vertical-align: top;
            padding: 2px 0px 2px 0px;
        }

        h5{
            font-weight: bold;
        }
        li{
            margin-left: 20px;
        }


/* <> */


        @font-face {
            font-family: 'Firefly';
            font-style: normal;
            font-weight: normal;
            src: url("../../public/fonts/firefly/Firefly Regular.ttf") format('truetype');
        }
        *{
            font-family: firefly, DejaVu Sans, sans-serif;
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<div class="container-fluid">

    <table>
        <tr>
            <td>
                <center>
                    
                    <img src="<?php echo !empty($user->profile_photo_url) ? $user->profile_photo_url : 'https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MXx8aHVtYW58ZW58MHx8MHw%3D&ixlib=rb-1.2.1&w=1000&q=80'; ?>" style="width: 100px; height: 100px; border-radius: 50px; border: 2px solid white;"/>

                    
                    <h5 style="margin-top: 20px"><?php echo !empty($user->name) ? $user->name :  ''; ?> <?php echo !empty($user->surname) ? $user->surname :  ''; ?></h5>

                    
                    <p><?php echo !empty($user->profile_name) ? $user->profile_name :  ''; ?></p>
                </center>
            </td>
        </tr>
        <tr>
            <td>
                <center>
                    <?php echo !empty($user->phone_number) ? $user->phone_number :  'No Number Yet'; ?> | <?php echo !empty($user->email) ? $user->email : 'No Email Yet'; ?> | <?php echo !empty($user->address) ? ($user->address . ',') :  ''; ?> <?php echo !empty($user->city) ? ($user->city . ',') :  ''; ?> <?php echo !empty($user->country) ? ($user->country . ',') :  ''; ?>

                    <hr style="margin-top: 2px">
                </center>
            </td>
        </tr>
        <tr>
            <td>
                <?php echo !empty($user->profile_description) ? $user->profile_description :  ''; ?><hr>
            </td>
        </tr>
    </table>
    


    <table>
        <tr>
            <td colspan="2" style="padding-bottom: 20px">
                <center><b>EMPLOYMENT HISTORY</b></center>
            </td>
        </tr>
        <?php $__currentLoopData = $user->employments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <b><?php echo $employment->position; ?></b> <span style="color: rgb(139, 139, 139)">| <?php echo $employment->from; ?> – <?php echo $employment->to; ?></span>
            </td>
        </tr>
        <tr>
            <td>
                <?php echo $employment->institute_name; ?> <span style="color: rgb(139, 139, 139)">| <?php echo $employment->city; ?>, <?php echo $employment->country; ?></span>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="color: rgb(139, 139, 139)">
                <?php $__currentLoopData = $user->employments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $employment->employmentResponsibilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment_responsibility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li><?php echo $employment_responsibility->name; ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
                <?php $__currentLoopData = $user->employments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $employment->employmentAchievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment_achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo $employment_achievement->name; ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="padding-bottom: 20px">
                <center><b>EDUCATION AND ACADEMICAL ACTIVITY</b></center>
            </td>
        </tr>
        <?php $__currentLoopData = $user->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <b><?php echo $education->specialty; ?> (<?php echo $education->degree; ?>)</b> <span style="color: rgb(139, 139, 139)">| <?php echo $education->from; ?> – Till <?php echo $education->to; ?></span>
                </td>
            </tr>
            <tr>
                <td>
                    <?php echo $education->faculty; ?>

                </td>
            </tr>
            <tr>
                <td>
                    <?php echo $education->institution; ?> 
                    <span style="color: rgb(139, 139, 139)">| 
                        
                    </span>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $user->academics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="padding-top: 20px">
                <b><?php echo $academic->activity_name; ?></b> <span style="color: rgb(139, 139, 139)"> | <?php echo $academic->from; ?> – Till <?php echo $academic->to; ?></span>
            </td>
        </tr>
        <tr>
            <td>
                <?php echo $academic->organization; ?>

                
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


    <table>
        <tr>
            <td colspan="3"  style="padding-bottom: 20px">
                <center><b>SKILLLS AND COMPETENCIES</b></center>
            </td>
        </tr>
        <?php
            $groupSkills = collect($user->skills)->groupBy('type');
        ?>
        <?php $__currentLoopData = $groupSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $groupSkill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php $__currentLoopData = $groupSkill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <?php echo $skill->name; ?> (<?php echo $skill->level; ?>) <br> 
                    
                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </table>


    <table>
        <tr>
            <td colspan="4"  style="padding-bottom: 20px">
                <center><b>REFERENCE</b></center>
            </td>
        </tr>
        <?php $__currentLoopData = $user->references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td>
                <?php echo $reference->name; ?> <?php echo $reference->surname; ?>

            </td>
            <td>
                <?php echo $reference->organization; ?>

            </td>
            <td>
                <?php echo $reference->position; ?>

            </td>
            <td>
                <?php echo $reference->phone_number; ?>

            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>

<br><br><br>
</body>
</html>
<?php /**PATH /mnt/c/Users/shahid/Desktop/CvTemplates/CvTemplates/resources/views/template4.blade.php ENDPATH**/ ?>