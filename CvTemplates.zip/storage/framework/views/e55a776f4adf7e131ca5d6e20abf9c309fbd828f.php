<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container-fluid mt-5">
        <div class="row">
            <div class="col-md-4">
                <p>
                    Profile text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
            </div>
            <div class="col-md-4">
                <img src="https://i.pinimg.com/236x/30/ce/c1/30cec15fd0a36aeb36ba34f4660b1844--square-faces-squares.jpg" width="200px" height="200px" style="border-radius: 50%">
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\projects\htdocs\laravel\CvTemplates\resources\views/template1.blade.php ENDPATH**/ ?>