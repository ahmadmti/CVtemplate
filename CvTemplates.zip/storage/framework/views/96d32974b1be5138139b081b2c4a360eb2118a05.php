<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CV Templates</title>
</head>
<body>
    <h1>
        <a href="templateOne">Template 1</a> => <a href="Template1">Download Template 01</a>
        <br><br>
        <a href="templateTwo">Template 2</a> => <a href="Template2">Download Template 02</a>
        <br><br>
        <a href="templateThree">Template 3</a> => <a href="Template3">Download Template 03</a>
        <br><br>
        <a href="templateFour">Template 4</a> => <a href="Template4">Download Template 04</a>
        <br><br>
        <a href="templateFive">Template 5</a> => <a href="Template5">Download Template 05</a>
    </h1>
</body>
</html>
<?php /**PATH D:\projects\htdocs\laravel\CvTemplates\resources\views/HomePage.blade.php ENDPATH**/ ?>