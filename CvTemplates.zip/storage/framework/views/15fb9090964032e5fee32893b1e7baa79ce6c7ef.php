<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <style>
        div {
            /* border: 1px solid #ff0000; */
            padding: 5px;
        }
        table, th, tr{
            width: 100%;
            /* border: 2px solid rgb(4, 0, 255); */
        }
        td{
            /* border: 2px solid rgb(4, 0, 255); */
        }
        *{
            font-size: 13px;
        }
        @font-face {
            font-family: DejaVuSerif;
            src: url('dompdf/lib/fonts/DejaVuSerif.tff');
        }

    </style>
</head>
<body>
<div class="container-fluid">

    <a href=<?php echo e(url('Template1')); ?>>download</a>

    <table style="margin-top: 20px">
        <tr>
            <td style="width: 75%">
                
                <p>
                    Profile text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.<hr style="margin-top: -10px">
                </p>

                
                <p>55577898741 &nbsp;&nbsp;&nbsp; <span>xyz@gmail.com</span></p>

                
                <p style="color: rgb(139, 139, 139)">Address, City, Country</p>
            </td>
            <td style="width: 25%">
                
                    <center>
                        
                        <img src="https://i.pinimg.com/236x/30/ce/c1/30cec15fd0a36aeb36ba34f4660b1844--square-faces-squares.jpg" style="border-radius: 1000px; width: 100px; height: 100px;"/>

                        
                        <h5 style="margin-top: 20px">NAME SURNAME</h5>

                        
                        <p>PROFILE TITLE</p>
                    </center>
                
            </td>
        </tr>
    </table>

</div>

<br><br><br>
</body>
</html>
<?php /**PATH D:\projects\htdocs\laravel\CvTemplates\resources\views/welcome.blade.php ENDPATH**/ ?>