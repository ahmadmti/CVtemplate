<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <style>
        div {
            /* border: 1px solid #ff0000; */
            padding: 5px;
        }
        table, th, tr{
            width: 100%;
            /* border: 2px solid rgb(4, 0, 255); */
        }
        td{
            /* border: 2px solid rgb(4, 0, 255); */
            vertical-align: top;
            padding: 2px 0px 2px 0px;
        }
        *{
            font-size: 13px;
        }
        h5{
            font-weight: bold;
        }
        li{
            margin-left: 20px;
        }
        @font-face {
            font-family: 'Firefly';
            font-style: normal;
            font-weight: normal;
            src: url("../../public/fonts/firefly/Firefly Regular.ttf") format('truetype');
        }
        *{
            font-family: firefly, DejaVu Sans, sans-serif;
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<div class="container-fluid">

    <table style="margin-top: 20px">
        <tr>
            <td style="width: 75%">
                
                <p>
                    <br>
                    <?php echo !empty($user->profile_description) ? $user->profile_description :  ''; ?><hr style="margin-top: -10px">
                </p>

                
                <p><?php echo !empty($user->phone_number) ? $user->phone_number :  'No Number Yet'; ?> &nbsp;&nbsp;&nbsp; <span><?php echo !empty($user->email) ? $user->email : 'No Email Yet'; ?></span></p>

                
                <p style="color: rgb(139, 139, 139)"><?php echo !empty($user->address) ? ($user->address . ',') :  ''; ?> <?php echo !empty($user->city) ? ($user->city . ',') :  ''; ?> <?php echo !empty($user->country) ? ($user->country . ',') :  ''; ?></p>
            </td>
            <td style="width: 25%">
                
                    <center>
                        
                        <img src="<?php echo !empty($user->profile_photo_url) ? $user->profile_photo_url : 'https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MXx8aHVtYW58ZW58MHx8MHw%3D&ixlib=rb-1.2.1&w=1000&q=80'; ?>" style="width: 100px; height: 100px; border-radius: 50px; border: 2px solid white;"/>

                        
                        <h5 style="margin-top: 20px"><?php echo !empty($user->name) ? $user->name :  ''; ?> <?php echo !empty($user->surname) ? $user->surname :  ''; ?></h5>

                        
                        <p><?php echo !empty($user->profile_name) ? $user->profile_name :  ''; ?></p>
                    </center>
                
            </td>
        </tr>
    </table>

    <br><br>

    <h5>Education<hr style="margin-top: 0px"></h5>

    <table>
        <?php $__currentLoopData = $user->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="width: 170px">
                    <p style="color: rgb(139, 139, 139)">
                        <?php echo $education->from; ?> - Till <?php echo $education->to; ?>

                    </p>
                </td>
                <td>
                    <p>
                        <b><?php echo $education->specialty; ?> (<?php echo $education->degree; ?>)</b>
                        <br>
                        <?php echo $education->faculty; ?> <?php echo $education->institution; ?>

                    </p>
                </td>
                <td style="width: 170px">
                    <p style="text-align: right;"><?php echo $education->city; ?> <br> <?php echo $education->country; ?></p>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


    
    <br><br>
    <h5>ACADEMICAL ACTIVITY<hr style="margin-top: 0px"></h5>

    <table>
        <?php $__currentLoopData = $user->academics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="width: 170px">
                    <p style="color: rgb(139, 139, 139)">
                        <?php echo $academic->from; ?> – <?php echo $academic->to; ?>

                    </p>
                </td>
                <td>
                    <p>
                        <b><?php echo $academic->activity_name; ?></b>
                        <br>
                        <?php echo $academic->organization; ?>

                    </p>
                </td>
                <td style="width: 170px">
                    <p style="text-align: right;"><?php echo $academic->city; ?> <br> <?php echo $academic->country; ?></p>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


    
    <br><br>
    <h5>EMPLOYMENT HISTORY<hr style="margin-top: 0px"></h5>

    <table>
        
        <?php $__currentLoopData = $user->employments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="width: 170px">
                    <p style="color: rgb(139, 139, 139)">
                        <?php echo $employment->from; ?> - <?php echo $employment->to; ?>

                    </p>
                </td>
                <td>
                    <p>
                        <b><?php echo $employment->position; ?></b>
                        <br>
                        <?php echo $employment->institute_name; ?>

                    </p>
                </td>
                <td style="width: 170px">
                    <p style="text-align: right;"><?php echo $employment->city; ?> <br> <?php echo $employment->country; ?></p>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        
            <tr>
                <td>
                    <p style="color: rgb(139, 139, 139)">
                        Responsibilities
                    </p>
                </td>
                <td>
                    <p>
                        <?php $__currentLoopData = $user->employments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $employment->employmentResponsibilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment_responsibility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo $employment_responsibility->name; ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </td>
                <td></td>
            </tr>

        
        <tr>
            <td>
                <p style="color: rgb(139, 139, 139)">
                    Achievements
                </p>
            </td>
            <td>
                <p>
                    <?php $__currentLoopData = $user->employments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $employment->employmentAchievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment_achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo $employment_achievement->name; ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
            </td>
            <td>

            </td>
        </tr>
    </table>


    
    <br><br>
    <h5>SKILLLS AND COMPETENCIES<hr style="margin-top: 0px"></h5>

    <?php
        $groupSkills = collect($user->skills)->groupBy('type');
    ?>
    <table>
        <?php $__currentLoopData = $groupSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $groupSkill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="width: 170px">
                    <p style="color: rgb(139, 139, 139)">
                        <?php echo str_replace('_', " ", $key); ?>

                    </p>
                </td>
                <td>
                    <p>
                        <?php $__currentLoopData = $groupSkill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo $skill->name; ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </td>
                <td>
                    <p>
                        <?php $__currentLoopData = $groupSkill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $skill->level; ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </td>
                <td style="width: 170px">
                    <p style="text-align: right;">
                        <?php $__currentLoopData = $groupSkill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


    
    <br><br>
    <h5>REFERENCE<hr style="margin-top: 0px"></h5>

    <table>
        <?php $__currentLoopData = $user->references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="width: 170px">
                    <p style="color: rgb(139, 139, 139)">
                        Name
                    </p>
                </td>
                <td>
                    <p>
                        <b><?php echo $reference->name; ?> <?php echo $reference->surname; ?></b>
                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="color: rgb(139, 139, 139)">
                        Organization Name
                    </p>
                </td>
                <td>
                    <p>
                        <?php echo $reference->organization; ?>

                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="color: rgb(139, 139, 139)">
                        Position
                    </p>
                </td>
                <td>
                    <p>
                        <?php echo $reference->position; ?>

                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="color: rgb(139, 139, 139)">
                        Numb
                    </p>
                </td>
                <td>
                    <p>
                        <?php echo $reference->phone_number; ?>

                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="color: rgb(139, 139, 139)">

                    </p>
                </td>
                <td>
                    <p>

                    </p>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


    <br><br>
    <h3>PORTFOLIO</h3>
    <br><br>

    
    <br><br>
    <h5>PROJECT NAME<hr style="margin-top: 0px"></h5>
    <?php $__currentLoopData = $user->portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <table>
        <tr>
            <td style="width: 400px">
                
                <?php echo $portfolio->date; ?></span> <br>
                <?php echo $portfolio->link; ?> <br><br>
                <?php echo $portfolio->description; ?>

            </td>
            <?php if($portfolio->photo): ?>
                <td>
                    <img src="<?php echo $portfolio->photo; ?>" width="300px" style="padding: 5px">
                </td>
            <?php endif; ?>
        </tr>
    </table>
    <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <br><br>
    <h3>MOTIVATION LETTER</h3>
    <br><br>

    <?php $__currentLoopData = $user->letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><b>Letter Recipient</b></p>
        <p style="color: rgb(139, 139, 139)"><?php echo $letter->company; ?> <br><?php echo $letter->position; ?> </p>
        <br><br><br><br><br><b><b></b></b>
        <hr>
        <p>
            <?php echo $letter->text; ?>

        </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <table style="margin-top: 100px">
    <tr>
        <td style="width: 300px"><b><?php echo $user->name; ?> <?php echo $user->surname; ?></b></td>
        <td rowspan="2"><?php echo $user->address; ?></td>
    </tr>
    <tr>
        <td><?php echo $user->dob; ?></td>
    </tr>
    </table>


</div>

<br><br><br>
</body>
</html>
<?php /**PATH /mnt/c/Users/shahid/Desktop/CvTemplates/CvTemplates/resources/views/template1.blade.php ENDPATH**/ ?>